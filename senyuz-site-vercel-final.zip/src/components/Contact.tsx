import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); setSubmitted(true); setTimeout(() => setSubmitted(false), 3000); };

  return (
    <section id="contact" className="py-32 lg:py-48 bg-[#FAFAFA]">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-20">
          <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-6">Visit Us</motion.p>
          <motion.h2 initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.1 }} className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] leading-tight">The <span className="italic">Boutique</span></motion.h2>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 1 }}>
            <p className="text-[15px] font-light text-[#555555] leading-[1.8] mb-12">We invite you to experience Şenyüz Saat & Gümüş in person.</p>
            <div className="space-y-8 mb-12">
              <div className="flex items-start gap-5"><MapPin size={20} className="text-[#8A8A8A] mt-1" strokeWidth={1} /><div><p className="text-[11px] tracking-[0.2em] uppercase text-[#8A8A8A] mb-2 font-light">Address</p><p className="text-[15px] font-light text-[#111111] leading-relaxed">Nişantaşı, Abdi İpekçi Cd. No: 42<br />Şişli, Istanbul 34367, Turkey</p></div></div>
              <div className="flex items-start gap-5"><Phone size={20} className="text-[#8A8A8A] mt-1" strokeWidth={1} /><div><p className="text-[11px] tracking-[0.2em] uppercase text-[#8A8A8A] mb-2 font-light">Telephone</p><p className="text-[15px] font-light text-[#111111]">+90 212 123 45 67</p></div></div>
              <div className="flex items-start gap-5"><Mail size={20} className="text-[#8A8A8A] mt-1" strokeWidth={1} /><div><p className="text-[11px] tracking-[0.2em] uppercase text-[#8A8A8A] mb-2 font-light">Email</p><p className="text-[15px] font-light text-[#111111]">concierge@senyuz.com</p></div></div>
              <div className="flex items-start gap-5"><Clock size={20} className="text-[#8A8A8A] mt-1" strokeWidth={1} /><div><p className="text-[11px] tracking-[0.2em] uppercase text-[#8A8A8A] mb-2 font-light">Hours</p><p className="text-[15px] font-light text-[#111111] leading-relaxed">Monday — Saturday: 10:00 — 19:00<br />Sunday: By Appointment</p></div></div>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.2 }}>
            <div className="bg-white p-10 lg:p-14 shadow-[0_4px_60px_rgba(0,0,0,0.04)]">
              <h3 className="font-serif text-2xl font-light text-[#111111] mb-2">Book an Appointment</h3>
              <p className="text-sm font-light text-[#8A8A8A] mb-10">Our consultants look forward to welcoming you</p>
              {submitted ? <div className="text-center py-12"><p className="font-serif text-2xl font-light text-[#111111] mb-4">Thank You</p><p className="text-sm font-light text-[#8A8A8A]">We will contact you shortly to confirm your appointment.</p></div> : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {(['name','email','phone'] as const).map((field) => <input key={field} type={field === 'email' ? 'email' : field === 'phone' ? 'tel' : 'text'} required={field !== 'phone'} value={formData[field]} onChange={(e) => setFormData({ ...formData, [field]: e.target.value })} className="w-full px-0 py-3 bg-transparent border-0 border-b border-[#EEEEEE] focus:border-[#111111] outline-none text-[15px] font-light text-[#111111] transition-colors duration-500" placeholder={field} />)}
                  <textarea rows={3} value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} className="w-full px-0 py-3 bg-transparent border-0 border-b border-[#EEEEEE] focus:border-[#111111] outline-none text-[15px] font-light text-[#111111] transition-colors duration-500 resize-none" placeholder="Tell us about your interests..." />
                  <button type="submit" className="btn-luxury w-full mt-8 text-[11px] tracking-[0.2em] uppercase font-medium px-10 py-4 bg-[#111111] text-white hover:bg-[#333333] transition-colors duration-500">Request Appointment</button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
