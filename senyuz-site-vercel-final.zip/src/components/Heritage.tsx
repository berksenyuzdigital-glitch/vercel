import { motion } from 'framer-motion';
import { useParallax } from '../hooks/useScrollAnimation';

export default function Heritage() {
  const parallaxRef = useParallax(0.15);
  return (
    <section id="heritage" className="py-32 lg:py-48 bg-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-20">
          <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-6">Our Heritage</motion.p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          <motion.div initial={{ opacity: 0, x: -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 1.2 }} className="lg:col-span-7">
            <div ref={parallaxRef} className="relative">
              <div className="img-zoom aspect-[16/10] overflow-hidden">
                <img src="/images/craftsmanship.jpg" alt="Master Craftsman at Work" className="w-full h-full object-cover" loading="lazy" />
              </div>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 1.2, delay: 0.2 }} className="lg:col-span-5 lg:pt-16">
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] leading-[1.1] mb-10">Four Decades of<br /><span className="italic">Excellence</span></h2>
            <div className="space-y-6 text-[15px] font-light text-[#555555] leading-[1.8]">
              <p>Founded in 1985 in the heart of Istanbul, Şenyüz Saat & Gümüş has been synonymous with uncompromising quality and timeless design.</p>
              <p>Every piece that bears our name is the result of meticulous craftsmanship, combining centuries-old techniques with contemporary design sensibilities.</p>
              <p>We believe that true luxury lies not in ostentation, but in the quiet confidence of exceptional quality.</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
