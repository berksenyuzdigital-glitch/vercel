import { Instagram, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#111111] text-white py-20 lg:py-24">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-16 mb-20">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center"><span className="font-serif text-xl font-light tracking-tight">Ş</span></div>
              <div className="flex flex-col leading-none"><span className="font-serif text-lg font-medium tracking-wide">ŞENYÜZ</span><span className="text-[10px] tracking-[0.3em] uppercase text-white/50 font-light">Saat & Gümüş</span></div>
            </div>
            <p className="text-sm font-light text-white/50 leading-relaxed">Timeless elegance since 1985.<br />Crafting exceptional timepieces<br />and fine silver jewelry.</p>
          </div>
          <div><p className="text-[10px] tracking-[0.3em] uppercase text-white/40 mb-6 font-light">Collections</p><ul className="space-y-4">{['Luxury Watches','Silver Jewelry','Exclusive Editions','Gift Selection'].map((item) => <li key={item}><a href="#signature" className="text-sm font-light text-white/60 hover:text-white transition-colors duration-500">{item}</a></li>)}</ul></div>
          <div><p className="text-[10px] tracking-[0.3em] uppercase text-white/40 mb-6 font-light">Maison</p><ul className="space-y-4">{['Our Heritage','Craftsmanship','Sustainability','Careers'].map((item) => <li key={item}><a href="#heritage" className="text-sm font-light text-white/60 hover:text-white transition-colors duration-500">{item}</a></li>)}</ul></div>
          <div>
            <p className="text-[10px] tracking-[0.3em] uppercase text-white/40 mb-6 font-light">Contact</p>
            <ul className="space-y-4 text-sm font-light text-white/60"><li>Nişantaşı, Istanbul</li><li>+90 212 123 45 67</li><li>concierge@senyuz.com</li></ul>
            <div className="flex gap-4 mt-8"><a href="#" className="p-2 border border-white/20 hover:border-white/50 transition-colors duration-500" aria-label="Instagram"><Instagram size={16} className="text-white/60" /></a><a href="#" className="p-2 border border-white/20 hover:border-white/50 transition-colors duration-500" aria-label="Facebook"><Facebook size={16} className="text-white/60" /></a></div>
          </div>
        </div>
        <div className="pt-10 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-6">
          <p className="text-[11px] font-light text-white/40 tracking-wide">© 2024 Şenyüz Saat & Gümüş. All rights reserved.</p>
          <div className="flex gap-8"><a href="#" className="text-[11px] font-light text-white/40 hover:text-white/70 transition-colors duration-500">Privacy Policy</a><a href="#" className="text-[11px] font-light text-white/40 hover:text-white/70 transition-colors duration-500">Terms of Service</a></div>
        </div>
      </div>
    </footer>
  );
}
