import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { label: 'Collections', href: '#collections' },
  { label: 'Signature', href: '#signature' },
  { label: 'Heritage', href: '#heritage' },
  { label: 'Boutique', href: '#contact' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <motion.nav initial={{ y: -100 }} animate={{ y: 0 }} transition={{ duration: 1, ease: [0.25, 0.46, 0.45, 0.94] }} className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-[0_1px_0_0_rgba(0,0,0,0.05)]' : 'bg-transparent'}`}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="flex items-center justify-between h-20 lg:h-24">
            <a href="#" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-full border border-current flex items-center justify-center transition-colors duration-500 group-hover:border-[#8A8A8A]">
                <span className="font-serif text-xl font-light tracking-tight">Ş</span>
              </div>
              <div className="hidden sm:flex flex-col leading-none">
                <span className="font-serif text-lg font-medium tracking-wide">ŞENYÜZ</span>
                <span className="text-[10px] tracking-[0.3em] uppercase text-[#8A8A8A] font-light">Saat & Gümüş</span>
              </div>
            </a>

            <div className="hidden lg:flex items-center gap-12">
              {navLinks.map((link) => (
                <a key={link.label} href={link.href} className="link-underline text-[13px] tracking-[0.15em] uppercase font-light text-[#111111] hover:text-[#8A8A8A] transition-colors duration-500">
                  {link.label}
                </a>
              ))}
            </div>

            <div className="hidden lg:flex items-center gap-8">
              <a href="#contact" className="text-[12px] tracking-[0.2em] uppercase font-medium px-8 py-3 border border-[#111111] hover:bg-[#111111] hover:text-white transition-all duration-500">Appointment</a>
            </div>

            <button onClick={() => setMenuOpen(!menuOpen)} className="lg:hidden p-2" aria-label="Toggle menu">
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </motion.nav>

      <AnimatePresence>
        {menuOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }} className="fixed inset-0 z-40 bg-white lg:hidden">
            <div className="flex flex-col items-center justify-center h-full gap-10">
              {navLinks.map((link, i) => (
                <motion.a key={link.label} href={link.href} onClick={() => setMenuOpen(false)} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 + 0.2, duration: 0.6 }} className="font-serif text-3xl font-light tracking-wide text-[#111111]">
                  {link.label}
                </motion.a>
              ))}
              <motion.a href="#contact" onClick={() => setMenuOpen(false)} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.6 }} className="mt-6 text-[12px] tracking-[0.2em] uppercase font-medium px-10 py-4 border border-[#111111]">
                Book Appointment
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
