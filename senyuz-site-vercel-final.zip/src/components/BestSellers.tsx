import { motion } from 'framer-motion';
import { useStaggerAnimation } from '../hooks/useScrollAnimation';

const products = [
  { name: 'Sapphire Silver Ring', category: 'Ring', price: '18,900 ₺', image: '/images/product-ring.jpg' },
  { name: 'Classic Silver Cuff', category: 'Bracelet', price: '24,500 ₺', image: '/images/product-cuff.jpg' },
  { name: 'Pearl Diver Watch', category: 'Watch', price: '89,000 ₺', image: '/images/product-ladies-watch.jpg' },
  { name: 'Pearl Drop Pendant', category: 'Necklace', price: '15,200 ₺', image: '/images/product-pendant.jpg' },
  { name: 'Diamond Stud Earrings', category: 'Earrings', price: '32,000 ₺', image: '/images/product-earrings.jpg' },
  { name: 'Heritage Timepiece', category: 'Watch', price: '156,000 ₺', image: '/images/luxury-watch.jpg' },
];

export default function BestSellers() {
  const containerRef = useStaggerAnimation('.product-item', 0.1);
  return (
    <section className="py-32 lg:py-48 bg-[#FAFAFA]">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-20">
          <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-6">Best Sellers</motion.p>
          <motion.h2 initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.1 }} className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] leading-tight">Most <span className="italic">Admired</span></motion.h2>
        </div>
        <div ref={containerRef} className="grid grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-16 lg:gap-x-10 lg:gap-y-20">
          {products.map((product) => (
            <div key={product.name} className="product-item group cursor-pointer">
              <div className="img-zoom relative aspect-square mb-6 overflow-hidden bg-white">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
              </div>
              <div className="text-center">
                <p className="text-[10px] tracking-[0.25em] uppercase text-[#8A8A8A] mb-2 font-light">{product.category}</p>
                <h3 className="font-serif text-lg lg:text-xl font-light text-[#111111] mb-2 group-hover:text-[#8A8A8A] transition-colors duration-500">{product.name}</h3>
                <p className="text-sm font-light text-[#555555]">{product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
