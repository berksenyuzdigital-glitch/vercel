import { motion } from 'framer-motion';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const products = [
  { name: 'The Heritage Chronograph', category: 'Luxury Watch', price: '125,000 ₺', image: '/images/hero-watch.jpg', description: 'A masterpiece of horological engineering, featuring a hand-wound mechanical movement and sapphire crystal caseback.' },
  { name: 'Silver Filigree Bracelet', category: 'Silver Jewelry', price: '28,500 ₺', image: '/images/silver-jewelry.jpg', description: 'Intricate filigree work by master artisans, crafted from 925 sterling silver with an antique finish.' },
];

export default function SignatureProducts() {
  const sectionRef = useScrollAnimation();
  return (
    <section id="signature" className="py-32 lg:py-48 bg-[#FAFAFA]">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-24">
          <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-6">Signature Pieces</motion.p>
          <motion.h2 initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.1 }} className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] leading-tight">Masterpieces of<br /><span className="italic">Craftsmanship</span></motion.h2>
        </div>
        <div ref={sectionRef} className="space-y-32">
          {products.map((product, index) => (
            <div key={product.name} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center ${index % 2 === 1 ? 'lg:direction-rtl' : ''}`}>
              <div className={`${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                <div className="img-zoom relative aspect-[4/5] overflow-hidden bg-white shadow-[0_4px_60px_rgba(0,0,0,0.06)]">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
                </div>
              </div>
              <div className={`${index % 2 === 1 ? 'lg:order-1 lg:text-right' : ''} py-8`}>
                <p className="text-[10px] tracking-[0.3em] uppercase text-[#8A8A8A] mb-4 font-light">{product.category}</p>
                <h3 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light text-[#111111] mb-6 leading-tight">{product.name}</h3>
                <p className="text-base font-light text-[#555555] leading-relaxed mb-8 max-w-md">{product.description}</p>
                <p className="font-serif text-2xl font-light text-[#111111] mb-10">{product.price}</p>
                <button className="btn-luxury text-[11px] tracking-[0.2em] uppercase font-medium px-10 py-4 border border-[#111111] hover:bg-[#111111] hover:text-white transition-all duration-500">Discover More</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
