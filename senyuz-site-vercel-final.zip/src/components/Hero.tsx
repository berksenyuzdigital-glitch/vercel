import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-white">
      <div className="absolute inset-0">
        <img src="/images/hero-watch.jpg" alt="Luxury Timepiece" className="w-full h-full object-cover opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-white/80" />
      </div>
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.3 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-8">Since 1985 — Istanbul</motion.p>
        <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2, delay: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }} className="font-serif text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-light text-[#111111] leading-[0.95] tracking-tight mb-8">Timeless<br /><span className="italic font-light">Elegance.</span></motion.h1>
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.9 }} className="text-base sm:text-lg font-light text-[#555555] tracking-wide max-w-xl mx-auto mb-14 leading-relaxed">Premium Watches, Silver Jewelry and Exclusive Collections</motion.p>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 1.2 }}>
          <a href="#collections" className="btn-luxury inline-flex items-center gap-3 text-[12px] tracking-[0.2em] uppercase font-medium px-10 py-4 bg-[#111111] text-white hover:bg-[#333333] transition-colors duration-500">Explore Collection</a>
        </motion.div>
      </div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2, duration: 1 }} className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
        <span className="text-[10px] tracking-[0.3em] uppercase text-[#8A8A8A]">Scroll</span>
        <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}>
          <ArrowDown size={16} className="text-[#8A8A8A]" />
        </motion.div>
      </motion.div>
    </section>
  );
}
