import { motion } from 'framer-motion';
import { useStaggerAnimation } from '../hooks/useScrollAnimation';

const collections = [
  { title: 'Luxury Watches', subtitle: 'Swiss Precision', image: '/images/luxury-watch.jpg', description: 'Timepieces of extraordinary craftsmanship' },
  { title: 'Silver Jewelry', subtitle: 'Artisan Heritage', image: '/images/silver-jewelry.jpg', description: 'Handcrafted elegance in sterling silver' },
  { title: 'Exclusive Collection', subtitle: 'Limited Editions', image: '/images/exclusive-necklace.jpg', description: 'Rare pieces for the discerning collector' },
];

export default function FeaturedCollections() {
  const containerRef = useStaggerAnimation('.collection-card', 0.2);
  return (
    <section id="collections" className="py-32 lg:py-48 bg-white">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-24">
          <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-6">Our Collections</motion.p>
          <motion.h2 initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.1 }} className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] leading-tight">Curated for the<br /><span className="italic">Exceptional</span></motion.h2>
        </div>
        <div ref={containerRef} className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
          {collections.map((collection) => (
            <a key={collection.title} href="#signature" className="collection-card group cursor-pointer">
              <div className="img-zoom relative aspect-[3/4] mb-8 overflow-hidden bg-[#F5F5F5]">
                <img src={collection.image} alt={collection.title} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-700" />
              </div>
              <div className="text-center">
                <p className="text-[10px] tracking-[0.3em] uppercase text-[#8A8A8A] mb-3 font-light">{collection.subtitle}</p>
                <h3 className="font-serif text-2xl lg:text-3xl font-light text-[#111111] mb-3 group-hover:text-[#8A8A8A] transition-colors duration-500">{collection.title}</h3>
                <p className="text-sm font-light text-[#8A8A8A] leading-relaxed">{collection.description}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
