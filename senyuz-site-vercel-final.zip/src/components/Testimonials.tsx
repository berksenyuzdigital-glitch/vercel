import { motion } from 'framer-motion';
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  { quote: 'The attention to detail in every piece is extraordinary. My Şenyüz timepiece has become more than a watch — it is a treasured heirloom that I will pass down to my son.', author: 'Mehmet Kaya', title: 'Collector, Istanbul' },
  { quote: 'I have collected watches for over twenty years, and the craftsmanship of Şenyüz rivals the finest Swiss houses.', author: 'Ayşe Yılmaz', title: 'Art Director, London' },
  { quote: 'From the moment I walked into their boutique, I knew I was experiencing something special.', author: 'Can Özdemir', title: 'Entrepreneur, Dubai' },
];

export default function Testimonials() {
  const [current, setCurrent] = useState(0);
  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  return (
    <section className="py-32 lg:py-48 bg-white">
      <div className="max-w-[1000px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-20">
          <motion.p initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="text-[11px] tracking-[0.4em] uppercase font-light text-[#8A8A8A] mb-6">Client Experience</motion.p>
          <motion.h2 initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 1, delay: 0.1 }} className="font-serif text-4xl sm:text-5xl lg:text-6xl font-light text-[#111111] leading-tight">Words of <span className="italic">Distinction</span></motion.h2>
        </div>
        <div className="relative">
          <div className="flex justify-center mb-12"><Quote size={32} className="text-[#C0C0C0]" strokeWidth={1} /></div>
          <div className="min-h-[200px] flex items-center justify-center">
            <motion.div key={current} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center">
              <blockquote className="font-serif text-xl sm:text-2xl lg:text-3xl font-light text-[#111111] leading-relaxed mb-10 max-w-3xl mx-auto italic">"{testimonials[current].quote}"</blockquote>
              <p className="text-sm font-medium tracking-wide text-[#111111] mb-1">{testimonials[current].author}</p>
              <p className="text-[11px] tracking-[0.2em] uppercase text-[#8A8A8A] font-light">{testimonials[current].title}</p>
            </motion.div>
          </div>
          <div className="flex items-center justify-center gap-8 mt-12">
            <button onClick={prev} className="p-3 border border-[#EEEEEE] hover:border-[#111111] transition-colors duration-500" aria-label="Previous testimonial"><ChevronLeft size={18} className="text-[#111111]" /></button>
            <div className="flex gap-3">{testimonials.map((_, i) => <button key={i} onClick={() => setCurrent(i)} className={`w-2 h-2 rounded-full transition-all duration-500 ${i === current ? 'bg-[#111111] w-6' : 'bg-[#C0C0C0]'}`} aria-label={`Go to testimonial ${i + 1}`} />)}</div>
            <button onClick={next} className="p-3 border border-[#EEEEEE] hover:border-[#111111] transition-colors duration-500" aria-label="Next testimonial"><ChevronRight size={18} className="text-[#111111]" /></button>
          </div>
        </div>
      </div>
    </section>
  );
}
